package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.arrow.ArrowController;
import com.mygdx.game.ballon.Ballon;
import com.mygdx.game.ballon.BallonController;
import com.mygdx.game.bow.Bow;

public class MeuJogo extends ApplicationAdapter {
	SpriteBatch batch;
	public static Bow bow;
	public static int score;
	public static int timer;
	public static Ballon ballon;
	public static AssetManager manager;
	public static InputMultiplexer multiplexer;

	public static void addInputProcessor(InputProcessor inputProcessor){
		if (multiplexer == null) multiplexer = new InputMultiplexer();
		multiplexer.addProcessor(inputProcessor);
		Gdx.input.setInputProcessor(multiplexer);
	}
	
	@Override
	public void create () {
		timer = 0;
		score = 0;
		batch = new SpriteBatch();
		manager = new AssetManager();
		manager.load("bow.png", Texture.class);
		manager.load("arrow.png", Texture.class);
		manager.load("chicken.png", Texture.class);

		manager.finishLoading();//trava o jogo
		bow = new Bow();
		ballon = new Ballon();
		BallonController.init();
		ArrowController.init();
	}

	@Override
	public void render () {
		ScreenUtils.clear(1, 0, 0, 1);
		Gdx.graphics.setTitle(Gdx.graphics.getFramesPerSecond()+"");
		batch.begin();

		bow.draw(batch, Gdx.graphics.getDeltaTime());
		ArrowController.draw(batch, Gdx.graphics.getDeltaTime());
		BallonController.draw(batch,Gdx.graphics.getDeltaTime());
		batch.end();

		timer++;
		if (timer >= 500){
			BallonController.set((float) (Math.random() * Gdx.graphics.getWidth()), 0);
			timer = 0;
		}
	}
	
	@Override
	public void dispose () {
		batch.dispose();
	}
}
